import discord
from discord.ext import commands

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"Bot is ready! Logged in as {bot.user}")

# ------------------ Phase 1 Commands ------------------

# 1. Warn Command
@bot.command()
@commands.has_permissions(manage_messages=True)
async def warn(ctx, member: discord.Member, *, reason=None):
    await ctx.send(f"{member.mention} has been warned. Reason: {reason}")

# 2. Mute Command
@bot.command()
@commands.has_permissions(manage_roles=True)
async def mute(ctx, member: discord.Member, *, reason=None):
    mute_role = discord.utils.get(ctx.guild.roles, name="Muted")
    if not mute_role:
        mute_role = await ctx.guild.create_role(name="Muted")
        for channel in ctx.guild.channels:
            await channel.set_permissions(mute_role, speak=False, send_messages=False)
    await member.add_roles(mute_role)
    await ctx.send(f"{member.mention} has been muted. Reason: {reason}")

# 3. Unmute Command
@bot.command()
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member):
    mute_role = discord.utils.get(ctx.guild.roles, name="Muted")
    if mute_role in member.roles:
        await member.remove_roles(mute_role)
        await ctx.send(f"{member.mention} has been unmuted.")
    else:
        await ctx.send("User is not muted.")

# 4. Ban Command
@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
    await member.ban(reason=reason)
    await ctx.send(f"{member.mention} has been banned. Reason: {reason}")

# 5. Kick Command
@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    await member.kick(reason=reason)
    await ctx.send(f"{member.mention} has been kicked. Reason: {reason}")

# ------------------ Phase 2 Commands ------------------

# Chatban Command
@bot.command()
@commands.has_permissions(manage_roles=True)
async def chatban(ctx, member: discord.Member):
    role = discord.utils.get(ctx.guild.roles, name="Chat Banned")
    if not role:
        role = await ctx.guild.create_role(name="Chat Banned")
        for channel in ctx.guild.text_channels:
            await channel.set_permissions(role, send_messages=False)
    await member.add_roles(role)
    await ctx.send(f"{member.mention} has been chat banned.")

# VCban Command
@bot.command()
@commands.has_permissions(manage_roles=True)
async def vcban(ctx, member: discord.Member):
    role = discord.utils.get(ctx.guild.roles, name="VC Banned")
    if not role:
        role = await ctx.guild.create_role(name="VC Banned")
        for channel in ctx.guild.voice_channels:
            await channel.set_permissions(role, connect=False)
    await member.add_roles(role)
    await ctx.send(f"{member.mention} has been VC banned.")

# Purge messages of a specific user
@bot.command()
@commands.has_permissions(manage_messages=True)
async def purge(ctx, member: discord.Member, limit: int = 100):
    def is_user(m):
        return m.author == member
    deleted = await ctx.channel.purge(limit=limit, check=is_user)
    await ctx.send(f"Deleted {len(deleted)} messages from {member.mention}", delete_after=5)

# Purge bot's messages
@bot.command(name="purgebot")
@commands.has_permissions(manage_messages=True)
async def purge_bot(ctx, limit: int = 100):
    def is_bot(m):
        return m.author == bot.user
    deleted = await ctx.channel.purge(limit=limit, check=is_bot)
    await ctx.send(f"Deleted {len(deleted)} bot messages.", delete_after=5)

# Lock the channel
@bot.command()
@commands.has_permissions(manage_channels=True)
async def lock(ctx):
    overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
    overwrite.send_messages = False
    await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
    await ctx.send("🔒 Channel locked.")

# Unlock the channel
@bot.command()
@commands.has_permissions(manage_channels=True)
async def unlock(ctx):
    overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
    overwrite.send_messages = True
    await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
    await ctx.send("🔓 Channel unlocked.")

# Hide the channel
@bot.command()
@commands.has_permissions(manage_channels=True)
async def hide(ctx):
    overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
    overwrite.view_channel = False
    await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
    await ctx.send("🙈 Channel hidden.")

# Unhide the channel
@bot.command()
@commands.has_permissions(manage_channels=True)
async def unhide(ctx):
    overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
    overwrite.view_channel = True
    await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
    await ctx.send("👀 Channel is now visible.")

bot.run("YOUR_BOT_TOKEN")

# ------------------ Phase 3 Commands ------------------

# Add Role to User
@bot.command()
@commands.has_permissions(manage_roles=True)
async def roleadd(ctx, member: discord.Member, *, role: discord.Role):
    await member.add_roles(role)
    await ctx.send(f"✅ Added role {role.name} to {member.mention}")

# Remove Role from User
@bot.command()
@commands.has_permissions(manage_roles=True)
async def roleremove(ctx, member: discord.Member, *, role: discord.Role):
    await member.remove_roles(role)
    await ctx.send(f"❌ Removed role {role.name} from {member.mention}")

# Steal Emoji
@bot.command()
async def steal_emoji(ctx, emoji: discord.PartialEmoji):
    if emoji.is_custom_emoji():
        emoji_data = await emoji.url.read()
        guild = ctx.guild
        new_emoji = await guild.create_custom_emoji(name=emoji.name, image=emoji_data)
        await ctx.send(f"Emoji stolen and added: <:{new_emoji.name}:{new_emoji.id}>")
    else:
        await ctx.send("Please use a custom emoji.")

# Remove Emoji
@bot.command()
@commands.has_permissions(manage_emojis=True)
async def remove_emoji(ctx, emoji: discord.Emoji):
    await emoji.delete()
    await ctx.send(f"Emoji {emoji.name} removed.")

# Steal Sticker
@bot.command()
async def steal_sticker(ctx):
    if ctx.message.reference:
        ref_msg = await ctx.channel.fetch_message(ctx.message.reference.message_id)
        if ref_msg.stickers:
            sticker = ref_msg.stickers[0]
            await ctx.send(f"Sticker Name: `{sticker.name}`
Sticker URL: {sticker.url}")
        else:
            await ctx.send("No sticker found in the replied message.")
    else:
        await ctx.send("Reply to a sticker to steal it.")

# Remove Sticker (by reply)
@bot.command()
@commands.has_permissions(manage_guild=True)
async def remove_sticker(ctx):
    if ctx.message.reference:
        ref_msg = await ctx.channel.fetch_message(ctx.message.reference.message_id)
        if ref_msg.stickers:
            sticker = ref_msg.stickers[0]
            await sticker.delete()
            await ctx.send(f"Sticker `{sticker.name}` removed.")
        else:
            await ctx.send("No sticker found in the replied message.")
    else:
        await ctx.send("Reply to a sticker to remove it.")

# Bulkrole - Add or Remove Role to Multiple Users
@bot.command()
@commands.has_permissions(manage_roles=True)
async def bulkrole(ctx, action: str, role: discord.Role, *members: discord.Member):
    count = 0
    for member in members:
        if action.lower() == "add":
            await member.add_roles(role)
            count += 1
        elif action.lower() == "remove":
            await member.remove_roles(role)
            count += 1
    await ctx.send(f"{action.title()}ed role `{role.name}` for {count} users.")